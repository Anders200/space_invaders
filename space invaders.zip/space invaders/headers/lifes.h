#ifndef LIFES_H
#define LIFES_H

#pragma once
#include <SFML/Graphics.hpp>

class lifes : public sf::RectangleShape
{
public:
    lifes();
    ~lifes();

private:

};

#endif